/*----------------------------------------------------------------------------------------------------*/
/**
  * @file    bsp_timers.c ������ ��� ������ � ���������
  * @brief
**/
/*----------------------------------------------------------------------------------------------------*/
#include "bsp_timers.h"

TIM_HandleTypeDef    	Tim2PWMHandle;
TIM_OC_InitTypeDef 	 	sConfigPWM;
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	������������� ��� ��������
  * @param	None
  * @reval	None
  */
void	BSP_TIM2PWM_Init()
{
	Tim2PWMHandle.Instance = TIM2;

	Tim2PWMHandle.Init.Prescaler     = 8;
	Tim2PWMHandle.Init.Period        = 0xFFFF - 1;
	Tim2PWMHandle.Init.ClockDivision = 0;
	Tim2PWMHandle.Init.CounterMode   = TIM_COUNTERMODE_UP;

	if(HAL_TIM_PWM_Init(&Tim2PWMHandle) != HAL_OK){
			Error_Handler();
	}

	sConfigPWM.OCMode     = TIM_OCMODE_PWM1;
	sConfigPWM.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigPWM.OCFastMode = TIM_OCFAST_DISABLE;

	sConfigPWM.Pulse = 1000;
	if(HAL_TIM_PWM_ConfigChannel(&Tim2PWMHandle, &sConfigPWM, TIM_CHANNEL_1) != HAL_OK){
			  Error_Handler();
	}

	sConfigPWM.Pulse = 2000;
	if(HAL_TIM_PWM_ConfigChannel(&Tim2PWMHandle, &sConfigPWM, TIM_CHANNEL_2) != HAL_OK){
				  Error_Handler();
	}

	sConfigPWM.Pulse = 3000;
	if(HAL_TIM_PWM_ConfigChannel(&Tim2PWMHandle, &sConfigPWM, TIM_CHANNEL_3) != HAL_OK){
					  Error_Handler();
	}

	sConfigPWM.Pulse = 4000;
	if(HAL_TIM_PWM_ConfigChannel(&Tim2PWMHandle, &sConfigPWM, TIM_CHANNEL_4) != HAL_OK){
						  Error_Handler();
	}
}
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	������ TIM2 PWM
  * @param	None
  * @reval	None
  */
void	BSP_TIM2PWM_Start()
{
	if(HAL_TIM_PWM_Start_IT(&Tim2PWMHandle, TIM_CHANNEL_1|TIM_CHANNEL_2|TIM_CHANNEL_3|TIM_CHANNEL_4) != HAL_OK)
			Error_Handler();
}
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	��������� TIM2 PWM
  * @param	None
  * @reval	None
  */
void 	BSP_TIM2PWM_Stop()
{
	if(HAL_TIM_PWM_Stop_IT(&Tim2PWMHandle, TIM_CHANNEL_1|TIM_CHANNEL_2|TIM_CHANNEL_3|TIM_CHANNEL_4) != HAL_OK)
		Error_Handler();
}
/*----------------------------------------------------------------------------------------------------*/
