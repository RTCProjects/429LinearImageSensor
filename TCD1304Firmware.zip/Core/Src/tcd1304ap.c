/*----------------------------------------------------------------------------------------------------*/
/**
  * @file    tcd1304.c ������ ��� ������ Toshiba TCD1304AP
  * @brief
**/
/*----------------------------------------------------------------------------------------------------*/
#include "tcd1304ap.h"
#include "bsp_adc.h"
#include "bsp_usb.h"

static uint16_t	icgTick = 0;

TIM_HandleTypeDef    Tim3PWMHandle;
TIM_OC_InitTypeDef 	 sConfigPWM;

tTCDADCData		tcdADCData;

uint16_t		sendCopyBuf1[TCD1304_DATA_SIZE];
uint16_t		sendCopyBuf2[TCD1304_DATA_SIZE];
uint16_t		sendCopyBuf3[TCD1304_DATA_SIZE];
uint16_t		sendCopyBuf4[TCD1304_DATA_SIZE];

osThreadId 		sensorTaskHandle;
xQueueHandle 	sensorADC1DataQueue;

void	TCD1304_Task(void const *argument);
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	������������� TCD1304AP
  * @param	None
  * @reval	None
  */
void	TCD1304_Init()
{
	sensorADC1DataQueue = xQueueCreate(TCD_QUEUE_SIZE, sizeof(tTCDADCData));

	osThreadDef(sensorTask, TCD1304_Task, osPriorityAboveNormal, 0, configMINIMAL_STACK_SIZE + 0x100);
	sensorTaskHandle = osThreadCreate(osThread(sensorTask), NULL);

	/*
	 * ������� ������� APB1 - 84Mhz
	 *
	 */

	Tim3PWMHandle.Instance = TIM3;

	Tim3PWMHandle.Init.Prescaler     = 4;
	Tim3PWMHandle.Init.Period        = 200 - 1;
	Tim3PWMHandle.Init.ClockDivision = 0;
	Tim3PWMHandle.Init.CounterMode   = TIM_COUNTERMODE_UP;

	if(HAL_TIM_PWM_Init(&Tim3PWMHandle) != HAL_OK){
		Error_Handler();
	}

	sConfigPWM.OCMode     = TIM_OCMODE_PWM1;
	sConfigPWM.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigPWM.OCFastMode = TIM_OCFAST_DISABLE;

	sConfigPWM.Pulse = 100;

	if(HAL_TIM_PWM_ConfigChannel(&Tim3PWMHandle, &sConfigPWM, TIM_CHANNEL_1) != HAL_OK){
		  Error_Handler();
		}
}
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	������ ��������� ���
  * @reval 	None
  */
void	TCD1304_Start()
{
	icgTick = 0;
	TIM3->CNT = 0;

	if(HAL_TIM_PWM_Start_IT(&Tim3PWMHandle, TIM_CHANNEL_1) != HAL_OK)
		Error_Handler();
}
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	��������� ��������� ���
  * @reval 	None
  */
void	TCD1304_Stop()
{
	if(HAL_TIM_PWM_Stop_IT(&Tim3PWMHandle, TIM_CHANNEL_1) != HAL_OK)
		Error_Handler();
}
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	�������� ����� ��������� ������ � �������
  * @reval 	None
  */
void	TCD1304_Task(void const * argument)
{

		portBASE_TYPE			 xStatus;

		while(1)
		{
			xStatus=xQueueReceive(sensorADC1DataQueue, &tcdADCData, portMAX_DELAY);
			if (xStatus == pdPASS) {

				if(tcdADCData.Adc == 1){

					uint16_t	*pADCData1 = tcdADCData.Data;
					uint16_t	*pADCData2 = tcdADCData.Data + 256;

					memcpy(sendCopyBuf1,pADCData1,sizeof(uint16_t) * 256);
					memcpy(sendCopyBuf2,pADCData2,sizeof(uint16_t) * 256);
					memset(sendCopyBuf1 + 192,0,sizeof(uint16_t) * 64);
				}
				if(tcdADCData.Adc == 2){
					memcpy(sendCopyBuf3,tcdADCData.Data,	  sizeof(uint16_t) * 256);
					memcpy(sendCopyBuf4,tcdADCData.Data + 256,sizeof(uint16_t) * 256);
				}
			}

		}
}
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	���������� DMA �� ADC
  * @param  adcValue: ��������� �� ��������� ������ � ADC
  * @reval 	None
  */
void	TCD1304_DataCallback(tTCDADCData	*adcValue)
{
	static portBASE_TYPE xHigherPriorityTaskWoken;

	xHigherPriorityTaskWoken = pdFALSE;

		xQueueSendToBackFromISR(sensorADC1DataQueue, adcValue, &xHigherPriorityTaskWoken);

	if (xHigherPriorityTaskWoken != pdFALSE) {
    // ������, ����������� ������������ ���������.
    portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
  }

}
/*----------------------------------------------------------------------------------------------------*/
/**
  * @brief	���������� DMA �� ADC
  * @param  htim : TIM handle
  * @reval 	None
  */
void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *hTim)
{
	if(hTim->Instance == TIM3)
	{
		if(icgTick==TCD1304_DELTA_TIME ){
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,GPIO_PIN_RESET);
		}
		if(icgTick>TCD1304_DELTA_TIME){
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,GPIO_PIN_SET);
			icgTick = 0;
			BSP_ADC_Start();
		}
		icgTick++;
	}
}
/*----------------------------------------------------------------------------------------------------*/


