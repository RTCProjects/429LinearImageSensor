/*
 * protocol.h
 *
 *  Created on: 23 ��� 2018 �.
 *      Author: O_o
 */

#ifndef INC_PROTOCOL_H_
#define INC_PROTOCOL_H_

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include <string.h>
#include <stdlib.h>

#define LINEAR_SENSOR_CMD		0x01
#define PWM_DATA_VALUE_CMD		0x80

uint8_t	*Protocol_GetPacketFromStream(uint8_t *pDataBuf,int sDataBuf, int	*pDataBufIndex, uint8_t	InputByte, int *packSize);
void	Protocol_Init(void);
void 	Protocol_SendLinearSensorDataPack(uint8_t	linearNumber,uint8_t packId,uint8_t	*pData,uint8_t	Len);
void 	Protocol_SendLinearSensorData(uint8_t	linearNumber,uint8_t	*pData);
void 	Protocol_RxPackageAnalysis(uint8_t	*pPackage);

#endif /* INC_PROTOCOL_H_ */
